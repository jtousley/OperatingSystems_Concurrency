Use on Linux only. Type "make;./run" without quotes to compile and run.

Problems, questions - email me: j.tousley@live.com

Example command:
	cat < makefile | grep run > output.txt